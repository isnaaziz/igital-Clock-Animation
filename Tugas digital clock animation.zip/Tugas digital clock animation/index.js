function currentTime() {
    var date = new Date();
    var hour = date.getHours();
    var min = date.getMinutes();
    var sec = date.getSeconds();
    var midday = "AM";
    midday = (hour >= 12) ? "PM" : "AM"; /* Menentukan waktu AM / PM */
    hour = (hour == 0) ? 12 : ((hour > 12) ? (hour - 12) : hour); /* menentukan  12-hour format */
    hour = changeTime(hour);
    min = changeTime(min);
    sec = changeTime(sec);
    document.getElementById("digit_time").innerText = hour + " : " + min + " : " + sec + " " + midday; /* menambahkan time ke div */
    var t = setTimeout(currentTime, 1000);
}

function changeTime(k) {
    if (k < 10) {
        return "0" + k;
    } else {
        return k;
    }
}

currentTime();